import java.util.Scanner;

public class TwoDimensionalEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ar[][]=new int[3][3];
Scanner sc=new Scanner(System.in);
		for(int i=0;i<3;++i)
		{
			for(int j=0;j<3;++j)
			{
				System.out.println("Enter the Number");
				ar[i][j]=sc.nextInt();

			}
			System.out.println();

		}
		
		//display details from array
		
		
		for(int i=0;i<3;++i)
		{
			int sum=0;
			for(int j=0;j<3;++j)
			{
				System.out.print(ar[i][j]+" ");
				sum+=ar[i][j];
				
			}
			System.out.print(" = "+ sum);

			System.out.println();
		}
		
		
		
		
		
		
		
		
		
	}

}
