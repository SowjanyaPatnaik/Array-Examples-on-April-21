import java.util.Arrays;

public class SorrtingArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	int []arr=new int[] {78,34,1,5,9,8,10};
		
		int []arr={78,34,1,5,9,8,10};
		
		System.out.println("Before Sorting :");
		for(int i=0;i<arr.length;++i)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println("After Sorting :");

		Arrays.sort(arr);
		
		for(int i=0;i<arr.length;++i)
		{
			System.out.print(arr[i]+" ");
		}
		


	}

}
