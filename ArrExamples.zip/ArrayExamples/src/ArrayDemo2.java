
public class ArrayDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ar[]= {100,200,300,400};

for(int j : ar)
	System.out.println(j);




	}

}
