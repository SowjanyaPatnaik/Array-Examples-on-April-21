
public class MaxEx {

static	void maxValue(int arr[])
	{
	int max=arr[0];//400
		for(int i=0;i<arr.length-1;++i)
		{
			if(arr[i+1]>max)//20>10,400>20,30>400, 90>400
			{
				max=arr[i+1];//20 400
			
			}
		}
		
		System.out.println("Max Value : "+max);

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ar[]= {10,20,400,30,90};
maxValue(ar);

	}

}
