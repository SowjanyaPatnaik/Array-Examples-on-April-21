import java.util.Scanner;

public class ArrayDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String ar[]=new String[3];

//Read the data dynamically store inside the array

Scanner sc=new Scanner(System.in);

for(int i=0;i<ar.length;++i)
{
	System.out.println("Enter The Name : ");
	ar[i]=sc.next();
}

//Display the data on console

for(String j : ar)
{
	System.out.print (j +" ");
}







	}

}
