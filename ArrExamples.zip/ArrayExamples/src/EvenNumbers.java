
public class EvenNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []arr={78,34,1,5,9,8,10};
		
		int []even=new int[7];
		int []odd=new int[7];
		int k=0;
		int n=0;
		for(int i=0;i<arr.length;++i)
		{
			if(arr[i]%2==0)
			{
			even[k]=arr[i];
			++k;
			}
			else
			{
				odd[n]=arr[i];
				++n;
			}
			
		}//end of the for loop
		
		System.out.println("Display Even Numbers");
		for(int j=0;j<even.length;++j)
		{
			if(even[j]!=0)
			System.out.print(even[j]+" ");
		}
		System.out.println();
		System.out.println("Display Odd Numbers");
		for(int j=0;j<odd.length;++j)
		{
			if(odd[j]!=0)
			System.out.print(odd[j]+" ");
		}
	}

}
