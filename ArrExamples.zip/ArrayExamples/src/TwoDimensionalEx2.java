
public class TwoDimensionalEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ar[][]= {{1,2,3},{2,3,6}};




//display details from array


		for(int i=0;i<2;++i)
		{
			int sum=0;
			for(int j=0;j<3;++j)
			{
				System.out.print(ar[i][j]+" ");
				sum+=ar[i][j];
				
			}
			System.out.print(" = "+ sum);

			System.out.println();
		}
		
		
		
		
		
		
		
		
		
	}

}