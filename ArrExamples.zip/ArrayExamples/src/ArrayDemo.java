
public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ar[]=new int[3];

System.out.println(ar[0]);
System.out.println(ar[1]);
System.out.println(ar[2]);
//System.out.println(ar[3]);//ArrayIndexOutOfBoundsException

ar[0]=100;
ar[2]=300;
System.out.println(ar[0]);
System.out.println(ar[1]);
System.out.println(ar[2]);

	}

}
