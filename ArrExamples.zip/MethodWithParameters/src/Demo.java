
public class Demo {

	public static void main(String[] args) {

		
		char ch='a';
		char ch1='b';
		char ch2=(char)(ch+ch1);
int ch3=ch+ch1;
System.out.println(ch2+"\t"+ch3);

System.out.println((int)ch+"\t"+(int)ch1);

	}

}
