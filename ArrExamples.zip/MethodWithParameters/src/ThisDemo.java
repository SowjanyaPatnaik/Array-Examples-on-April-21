
public class ThisDemo {

	int x=10;
	int k=100;
	static int j=20;
	void funX(int k)
	{
		System.out.println("Before Using This Keyword ");
		System.out.println(x+"\t"+k+"\t"+j);//10 1000 20
		System.out.println("After Using This Keyword ");
		System.out.println(this.x+"\t"+this.k+"\t"+this.j);//10 1000 20
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThisDemo demo=new ThisDemo();
		demo.funX(1000);
	}

}
